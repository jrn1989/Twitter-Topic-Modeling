README

This readme is to describe the use of different java libs in this folder

twitter4j-*.jar: is used to call the twitter APIs in java
mysql-*.jar: used to connect from java to mysql database
log4j-*.jar, commons-logging-*.jar: used to log
