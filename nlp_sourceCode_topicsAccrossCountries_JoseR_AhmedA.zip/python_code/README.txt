README

This readme file is to describe the purpose of the python files

af.py: read a similarity matrix and apply a affinity propagation clustering on that matrix

preprocessing_html.py: to preprocess the data found in a html document (.html file). It removes the metainformation, removes stop-words, look up in an english dictionary and stemming

preprocessing_tweet.py: to preprocess the data found in a tweet (.txt file). It removes the hashtag, removes stop-words, look up in an english dictionary and stemming
